Noshow_Udacity




Data created


This project was created on 25th April 2019.

Data Analytics Nanodegree Project on No_show Appointment.
Descriptive analytics of a collection of data of 100k medical appointments in Brazil and is focused on the question of whether or not patients show up for their appointment.

The following questions are asked;

What factor made people show up?
Is their a particular illness that makes the patient to likely show up?
The following steps was taken on the project

Introduction
Data Wrangling
Exploratory Data Analysis
Conclusion
